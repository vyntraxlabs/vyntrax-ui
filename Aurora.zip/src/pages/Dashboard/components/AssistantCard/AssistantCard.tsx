import { useEffect, useState } from "react";

import { DashboardService } from "../../../../services";
import "./AssistantCard.css";

import { Sparkles } from "lucide-react";

import { Card } from "../../../../components";

export function AssistantCard() {
  const hour = new Date().getHours();

  const greeting =
    hour < 12
      ? "Good Morning"
      : hour < 18
      ? "Good Afternoon"
      : "Good Evening";

  return (
    <Card>
      <div className="assistant-card">
        <div className="assistant-header">
          <Sparkles size={22} />

          <div>
            <h2>{greeting}, Renato.</h2>

            <p>All home systems are operational.</p>
          </div>
        </div>

        <div className="assistant-status">
          <div>
            <strong>12</strong>
            <span>Devices Online</span>
          </div>

          <div>
            <strong>4</strong>
            <span>Cameras Recording</span>
          </div>

          <div>
            <strong>ARMED</strong>
            <span>Security</span>
          </div>
        </div>
      </div>
    </Card>
  );
}