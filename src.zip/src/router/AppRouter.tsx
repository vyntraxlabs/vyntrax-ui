import { BrowserRouter, Navigate, Route, Routes } from "react-router-dom";

import { Dashboard, Devices, Login, Cameras, Security, AIAssistant, Settings } from "../pages";

export function AppRouter() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Navigate to="/dashboard" replace />} />

        <Route path="/login" element={<Login />} />

        <Route path="/dashboard" element={<Dashboard />} />

        <Route path="/devices" element={<Devices />} />

        <Route path="/cameras" element={<Cameras />} />

        <Route path="/security" element={<Security />} />

        <Route path="/ai-assistant" element={<AIAssistant />} />

        <Route path="/settings" element={<Settings />} />
      </Routes>
    </BrowserRouter>
  );
}
