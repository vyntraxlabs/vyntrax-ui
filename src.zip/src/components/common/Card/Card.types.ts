import type {
  HTMLAttributes,
  ReactNode,
} from "react";

export interface CardProps
  extends HTMLAttributes<HTMLDivElement> {
  children: ReactNode;

  title?: string;

  subtitle?: string;
}