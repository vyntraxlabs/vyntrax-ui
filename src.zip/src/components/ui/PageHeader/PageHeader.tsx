import "./PageHeader.css";

import { cn } from "../../../utils";

import type { PageHeaderProps } from "./PageHeader.types.ts";

export function PageHeader({
  title,
  subtitle,
  children,
  className,
  ...props
}: PageHeaderProps) {
  return (
    <header
      className={cn("vyntrax-page-header", className)}
      {...props}
    >
      <div className="vyntrax-page-header-content">
        <h1>{title}</h1>

        {subtitle && (
          <p>{subtitle}</p>
        )}
      </div>

      {children && (
        <div className="vyntrax-page-header-actions">
          {children}
        </div>
      )}
    </header>
  );
}