import type {
  HTMLAttributes,
  ReactNode,
} from "react";

export interface PageHeaderProps
  extends HTMLAttributes<HTMLDivElement> {
  title: string;
  subtitle?: string;
  children?: ReactNode;
}