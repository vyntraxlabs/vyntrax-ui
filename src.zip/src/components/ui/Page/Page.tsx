import "./Page.css";

import { cn } from "../../../utils";

import type { PageProps } from "./Page.types.ts";

export function Page({
  children,
  className,
  ...props
}: PageProps) {
  return (
    <section
      className={cn("vyntrax-page", className)}
      {...props}
    >
      {children}
    </section>
  );
}