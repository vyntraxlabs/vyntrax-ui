import type {
  HTMLAttributes,
  ReactNode,
} from "react";

export interface PageProps
  extends HTMLAttributes<HTMLDivElement> {
  children: ReactNode;
}