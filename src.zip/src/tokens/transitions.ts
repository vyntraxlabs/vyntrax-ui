export const transitions = {
  fast: "150ms",
  normal: "250ms",
  slow: "400ms",
} as const